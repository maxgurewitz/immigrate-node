module Constants where

companyName = "Naturalize"
